AI Project 02 - Coloring Puzzle

19127003 - Nguyễn Hữu Đạt
19127395 - Phan Đức Hiển
19127456 - Nguyễn Thanh Kiên

Hướng dẫn sử dụng:
- Cài đặt Python 3.x
- Cài đặt các module: Tkinter, pysat
- Biên dịch file gui.py trong thư mục src
- Chọn file input và thuật toán sử dụng và nhấn "Start"


