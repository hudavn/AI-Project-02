from utility import *

InputData("input.txt")
makeCNF()
Coloring()
visualized()
