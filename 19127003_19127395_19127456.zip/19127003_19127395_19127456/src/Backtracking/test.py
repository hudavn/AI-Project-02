from utility import *

InputData("input.txt")
Coloring(0)
visualized()    
