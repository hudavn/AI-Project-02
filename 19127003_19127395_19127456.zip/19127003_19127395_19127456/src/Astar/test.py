from utility import *

InputData("input.txt")
makeCNF()
Coloring(0, 0)
visualized()


